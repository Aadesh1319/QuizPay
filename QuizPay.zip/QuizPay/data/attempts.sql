-- Dump of table `quiz_attempts`
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (1,1,'technology',0,'0.00','2025-11-22 15:24:02');
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (2,1,'technology',4,'400.00','2025-11-22 15:47:58');
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (3,1,'technology',1,'100.00','2025-11-22 16:14:00');
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (4,1,'technology',2,'200.00','2025-11-22 20:21:50');
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (5,1,'technology',0,'0.00','2025-11-22 20:26:58');
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (6,2,'technology',4,'400.00','2025-11-22 21:20:08');
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (7,2,'science',2,'200.00','2025-11-22 21:20:55');
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (8,1,'technology',3,'300.00','2025-11-23 22:00:12');
INSERT INTO `quiz_attempts` (`id`,`user_id`,`subject`,`score`,`reward`,`timestamp`) VALUES (9,3,'technology',4,'400.00','2025-11-27 12:25:12');
